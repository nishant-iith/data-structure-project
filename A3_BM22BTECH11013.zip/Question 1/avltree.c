#include <stdio.h>
#include <stdlib.h>

struct Node
{
    int data;
    int height;
    struct Node *left;
    struct Node *right;
    struct Node *parent;
};

struct Node *createNode(int value)
{
    struct Node *newNode = (struct Node *)malloc(sizeof(struct Node));
    newNode->data = value;
    newNode->height = 0;
    newNode->left = NULL;
    newNode->right = NULL;
    newNode->parent = NULL;
    return newNode;
}

int get_height(struct Node *node)
{
    if (node == NULL)
    {
        return -1;
    }
    return node->height;
}

void update_height(struct Node *node)
{
    if (node == NULL)
    {
        return;
    }

    update_height(node->left);
    update_height(node->right);

    int leftHeight = (node->left != NULL) ? node->left->height : -1;
    int rightHeight = (node->right != NULL) ? node->right->height : -1;

    node->height = 1 + (leftHeight > rightHeight ? leftHeight : rightHeight);
}

int Balancefactor(struct Node *node)
{
    return get_height(node->left) - get_height(node->right);
}

struct Node *rightRotate(struct Node *q)
{
    struct Node *p = q->left;
    struct Node *b = p->right;

    p->right = q;
    q->left = b;

    update_height(q);
    update_height(p);

    return p;
}

struct Node *leftRotate(struct Node *p)
{
    struct Node *q = p->right;
    struct Node *b = q->left;

    q->left = p;
    p->right = b;

    update_height(p);
    update_height(q);

    return q;
}

struct Node *insertion_AVL(struct Node *root, int data)
{
    if (root == NULL)
    {
        root = createNode(data);
        return root;
    }

    if (data > root->data)
    {
        root->right = insertion_AVL(root->right, data);
        root->right->parent = root;
    }
    else if (data < root->data)
    {
        root->left = insertion_AVL(root->left, data);
        root->left->parent = root;
    }
    else
    {
        return root;
    }

    update_height(root);

    int balancefactorcheck = Balancefactor(root);

    if (balancefactorcheck < -1 && data > root->right->data)
    {
        return leftRotate(root);
    }

    if (balancefactorcheck < -1 && data < root->right->data)
    {
        root->right = rightRotate(root->right);
        return leftRotate(root);
    }

    if (balancefactorcheck > 1 && data > root->left->data)
    {
        root->left = leftRotate(root->left);
        return rightRotate(root);
    }

    if (balancefactorcheck > 1 && data < root->left->data)
    {
        return rightRotate(root);
    }

    update_height(root);
    return root;
}

struct Node *minvalue(struct Node *root)
{
    struct Node *temp = root;
    while (temp->left != NULL)
    {
        temp = temp->left;
    }
    return temp;
}

struct Node *deleteFromAVL(struct Node *root, int datatobedeleted)
{
    if (root == NULL)
    {
        return root;
    }

    if (datatobedeleted < root->data)
    {
        root->left = deleteFromAVL(root->left, datatobedeleted);
        if (root->left != NULL)
        {
            root->left->parent = root;
        }
    }
    else if (datatobedeleted > root->data)
    {
        root->right = deleteFromAVL(root->right, datatobedeleted);
        if (root->right != NULL)
        {
            root->right->parent = root;
        }
    }
    else
    {
        if (root->left == NULL || root->right == NULL)
        {
            struct Node *temp = (root->left) ? root->left : root->right;

            if (temp == NULL)
            {
                temp = root;
                root = NULL;
            }
            else
            {
                *root = *temp;
                root->parent = temp->parent;
            }

            free(temp);
        }
        else
        {
            struct Node *temp = minvalue(root->right);
            root->data = temp->data;
            root->right = deleteFromAVL(root->right, temp->data);
            if (root->right != NULL)
            {
                root->right->parent = root;
            }
        }
    }

    if (root == NULL)
    {
        return root;
    }

    update_height(root);

    int balancefactorcheck = Balancefactor(root);

    if (balancefactorcheck < -1)
    {
        if (Balancefactor(root->right) <= 0)
        {
            return leftRotate(root);
        }
        else
        {
            root->right = rightRotate(root->right);
            return leftRotate(root);
        }
    }

    if (balancefactorcheck > 1)
    {
        if (Balancefactor(root->left) >= 0)
        {
            return rightRotate(root);
        }
        else
        {
            root->left = leftRotate(root->left);
            return rightRotate(root);
        }
    }

    return root;
}


// Function to perform inorder traversal and print the result
void inorderTraversal(struct Node *node, FILE *output)
{
    if (node == NULL)
    {
        return;
    }

    inorderTraversal(node->left, output);
    fprintf(output, "%d(%d) ", node->data, node->height);
    inorderTraversal(node->right, output);
}

