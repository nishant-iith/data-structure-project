#include <stdio.h>
#include <stdlib.h>
#include "avltree.c"

struct probesDone
{
    int count;
};

int hashKeyIndex(int k){
    // hash function h1(k)=(7*k+5)
    // odd x even = even and odd x odd = odd
    return (((7*k)+5)%20);
}

// Function to search for a key in the AVL tree and keep track of probes
struct Node *searchWithProbes(struct Node *root, int key, struct probesDone *probes)
{
    if (root == NULL || root->data == key)
    {
        probes->count++;
        return root;
    }

    probes->count++;
    if (key < root->data)
    {
        return searchWithProbes(root->left, key, probes);
    }
    else
    {
        return searchWithProbes(root->right, key, probes);
    }
}

// Function to check if a number exists in an array
int existsInArray(int number, int array[], int size)
{
    for (int i = 0; i < size; i++)
    {
        if (array[i] == number)
        {
            return 1; // Number exists in the array
        }
    }
    return 0; // Number does not exist in the array
}

// Function to perform search and report the number of probes
void searchAndReportProbes(struct Node *avlRoot[], int keys[], int numKeys, const char *operationName, FILE *f4, FILE *f5)
{
    struct probesDone probes = {0};
    int totalProbes = 0;

    for (int i = 0; i < numKeys; i++)
    {
        int keyIndex = hashKeyIndex(keys[i]);

        printf("%d: hashing index (%d/20)\n", keys[i], keyIndex);
        fprintf(f5, " %d(%d) ->",keys[i], i+1);

        searchWithProbes(avlRoot[keyIndex], keys[i], &probes);
        totalProbes += probes.count;

        printf("for key %d : Number of probes %d\n", keys[i], probes.count);
        fprintf(f5, " %d\t", probes.count);

        probes.count = 0;
    }

fprintf(f4, "Probes for %s:\n", operationName);
fprintf(f4, "Total probes: %d\n", totalProbes);
fprintf(f4, "Average probes per search: %.2f\n", (float)totalProbes / numKeys);

}

int main()
{
    struct Node *avlRoot[20] = {NULL};

    int outputArray[1000];
    int forSearchingTest100StudentsFromOutputArray[100] = {0};
    int forSearchingTest100StudentsFrom1to1MillionWhichAreNotInOutputArray[100] = {0};
    int forsearchingAgain[100] = {0};

    // Open a file for reading
    FILE *f1 = fopen("output.txt", "r");
    FILE *f3 = fopen("output2.txt", "r");
    FILE *f2 = fopen("hashTable.txt", "w");
    FILE *f4 = fopen("Probe.txt", "w");
    FILE *f5 = fopen("ProbeComparision.txt", "w");

if (f1 == NULL || f2 == NULL || f3 == NULL || f4 == NULL || f5 == NULL) {
    printf("Error opening one of the files.\n");
    return 1;
}

    int i = 0;
    int studentAadhar;
    while (fscanf(f1, "%d", &studentAadhar) == 1)
    {
        outputArray[i] = studentAadhar;
        int index = hashKeyIndex(studentAadhar);
        // int index = studentAadhar % 20;
        avlRoot[index] = insertion_AVL(avlRoot[index], studentAadhar);
        i++;
    }

    int selectedAadharPresent;
    int j = 0;
    while (j < 100)
    {
        fscanf(f3, "%d", &selectedAadharPresent);
        forSearchingTest100StudentsFromOutputArray[j] = selectedAadharPresent;
        j++;
    }
    // printf("\n");

    int selectedAadharAbsent;
    int k = 0;
    while (k < 100)
    {
        fscanf(f3, "%d", &selectedAadharAbsent);
        forSearchingTest100StudentsFrom1to1MillionWhichAreNotInOutputArray[k] = selectedAadharAbsent;
        k++;
    }
    // printf("\n");

    int selectedAadharAgain;
    int l = 0;
    while (l < 100)
    {
        fscanf(f3, "%d", &selectedAadharAgain);
        forsearchingAgain[l] = selectedAadharAgain;
        l++;
    }

    for (int i = 0; i < 20; i++)
    {
        fprintf(f2, "Inorder traversal of AVL tree (%d): ", i + 1);
        inorderTraversal(avlRoot[i], f2);
        fprintf(f2, "\n");
    }

    // Now, let us perform the search operations and report probes
    searchAndReportProbes(avlRoot, forSearchingTest100StudentsFromOutputArray, 100, "100 successful searches from outputArray", f4, f5);

    for (int i = 0; i < 100; i++)
    {
        int keyindex = hashKeyIndex(forSearchingTest100StudentsFromOutputArray[i]);
        deleteFromAVL(avlRoot[keyindex], forSearchingTest100StudentsFromOutputArray[i]);
    }
    
    fprintf(f5, "\n");
    searchAndReportProbes(avlRoot, forsearchingAgain, 100, "100 successful searches from outputArray", f4, f5);

    fprintf(f5, "\n");
    searchAndReportProbes(avlRoot, forSearchingTest100StudentsFrom1to1MillionWhichAreNotInOutputArray, 100, "100 unsuccessful searches", f4, f5);

    fclose(f1);
    fclose(f2);
    fclose(f3);
    fclose(f4);
    fclose(f5);

    return 0;
}