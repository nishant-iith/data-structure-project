#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Function to check if a number exists in an array
int existsInArray(int number, int array[], int size) {
    for (int i = 0; i < size; i++) {
        if (array[i] == number) {
            return 1; // Number exists in the array
        }
    }
    return 0; // Number does not exist in the array
}

int main() {
    srand(time(NULL)); // Seed the random number generator

    int students[1000]; // Array to store 1000 unique students (Aadhar numbers)
    int studentCount = 0; // Count of unique students

    while (studentCount < 1000) {
        int aadhar = 1 + rand() % 10000000; // Generate a random Aadhar number within the range of 1 to 10 million

        // Check if the generated Aadhar number is unique
        if (!existsInArray(aadhar, students, studentCount)) {
            students[studentCount] = aadhar; // Store the unique Aadhar number
            studentCount++; // Increment the count of unique students
        }
    }

    // Open a file for writing
    FILE *file = fopen("output.txt", "w");

    if (file == NULL) {
        printf("Error opening the file!\n");
        return 1;
    }

    // Write the generated Aadhar numbers to the file
    // fprintf(file, "Aadhar numbers of 1000 students interested in Cricket : \n");
    for (int i = 0; i < 1000; i++) {
        fprintf(file, "%d\t", students[i]);
    }

    // Close the file
    fclose(file);

    printf("Generated and saved 1000 unique students (Aadhar numbers) to 'output.txt'.\n");

    return 0;
}
