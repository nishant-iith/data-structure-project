#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Function to check if a number exists in an array
int existsInArray(int number, int array[], int size) {
    for (int i = 0; i < size; i++) {
        if (array[i] == number) {
            return 1; // Number exists in the array
        }
    }
    return 0; // Number does not exist in the array
}

int main() {
    srand(time(NULL));

    int outputArray[1000] = {0};
    int forSearchingTest100StudentsFromOutputArray[100] = {0};
    int forSearchingTest100StudentsFrom1to1MillionWhichAreNotInOutputArray[100] = {0};
    int forSearchingTest[100]= {0};

    
    // Open a file for reading
    FILE *f1 = fopen("output.txt", "r");

    if (f1 == NULL) {
        printf("Error openign the file.\n");
        return 1;
    }

        int i = 0;
        int studentAadhar;
        while (fscanf(f1, "%d", &studentAadhar)==1)
        {
            outputArray[i] = studentAadhar;
            i++;
        }

    // Generate a random array of 100 unique studentAadhar numbers from the output array
    int j = 0;
    while (j < 100) {
        int randomIndex = rand() % 1000;
        if (!existsInArray(outputArray[randomIndex], forSearchingTest100StudentsFromOutputArray, 100)) {
            forSearchingTest100StudentsFromOutputArray[j] = outputArray[randomIndex];
            j++;
        }
    }

    // Generate a random array of 100 studentAadhar numbers not in the output array
    int k = 0;
    while (k < 100) {
        int randomAadhar = rand() % 10000000;
        if (!existsInArray(randomAadhar, forSearchingTest100StudentsFrom1to1MillionWhichAreNotInOutputArray, 100) &&
            !existsInArray(randomAadhar, outputArray, 1000)) {
            forSearchingTest100StudentsFrom1to1MillionWhichAreNotInOutputArray[k] = randomAadhar;
            k++;
        }
    }

    int l = 0;
    while (l < 100) {
        int randomsecond = rand() % 1000;
        if (!existsInArray(outputArray[randomsecond], forSearchingTest100StudentsFromOutputArray, 100) &&
            !existsInArray(outputArray[randomsecond], forSearchingTest, 100)) {
            forSearchingTest[l] = outputArray[randomsecond];
            // printf("%d \n", forSearchingTest[l]);
            l++;
        }
    }

    // Write the arrays to an output file
    FILE *outputFile = fopen("output2.txt", "w");
    if (outputFile == NULL) {
        printf("Error opening the output file.\n");
        return 1;
    }

    // Write forSearchingTest100StudentsFromOutputArray to the first row
    for (int i = 0; i < 100; i++) {
        fprintf(outputFile, "%d ", forSearchingTest100StudentsFromOutputArray[i]);
    }
    fprintf(outputFile, "\n");

    // Write forSearchingTest100StudentsFrom1to1MillionWhichAreNotInOutputArray to the second row
    for (int i = 0; i < 100; i++) {
        fprintf(outputFile, "%d ", forSearchingTest100StudentsFrom1to1MillionWhichAreNotInOutputArray[i]);
    }
    fprintf(outputFile, "\n");

    // Write for searching Test to third row
    for (int i = 0; i < 100; i++)
    {
        fprintf(outputFile, "%d ", forSearchingTest[i]);
    }
    

    printf("Done!\n");

    fclose(outputFile);

    return 0;
}
