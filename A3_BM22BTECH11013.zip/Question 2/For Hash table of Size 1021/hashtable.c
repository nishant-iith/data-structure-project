#include <stdio.h>
#include <stdbool.h>

#define hashTableSize 1021

int hashfunction1(int k) {
    return (7 * k + 5);
}

int hashfunction2(int k) {
    return (5 * k + 7);
}

int location_u(int key) {
    return hashfunction1(key) % hashTableSize;
}

int location_v(int key) {
    return hashfunction2(key) % hashTableSize;
}

bool isEmpty(int array[], int location) {
    return array[location] == 0;
}

int final_location(int array[], int key, int tableSize) {
    for (int i = 0; i < tableSize; i++) {
        int location = (location_u(key) + i * location_v(key)) % tableSize;
        if (isEmpty(array, location)) {
            return location;
        }
    }
    printf("Could not store %d\n", key);
    return -1;
}

void insertIntoTable(int array[], int key, int tableSize) {
    int initialLocation = location_u(key);
    int finalLocation = initialLocation;

    for (int i = 0; i < tableSize; i++) {
        if (isEmpty(array, finalLocation)) {
            array[finalLocation] = key;
            return;
        }
        finalLocation = (initialLocation + i * location_v(key)) % tableSize;
    }

    printf("Could not insert key %d\n", key);
}

int probesReportInSearching(int array[], int key, const char *operationName, FILE *f3) {
    int probes = 0;
    int location = location_u(key);

    for (int i = 0; i < hashTableSize; i++) {
        int currentLocation = (location + i * location_v(key)) % hashTableSize;
        probes++;
        if (array[currentLocation] == key) {
            fprintf(f3, "%s (%d) %d\n", operationName, key, probes); // Print successful searches with a newline
            return probes;
        }
        if (isEmpty(array, currentLocation)) {
            fprintf(f3, "%s (%d) %d\n", operationName, key, probes); // Print unsuccessful searches with a newline
            return probes; // Key not found
        }
    }

    return probes;
}
