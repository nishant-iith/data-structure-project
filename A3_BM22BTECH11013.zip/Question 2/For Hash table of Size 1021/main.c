#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "hashtable.c"

#define sizeAfterdeletion 900 // 20-7

int main()
{
    int mainArray[1000] = {0};
    int hashTable1[hashTableSize] = {0};
    int AadharPresent[100] = {0};
    int keysIndexToBeDeletedFromHashTable[100] = {0};
    int updatedMainArray[sizeAfterdeletion] = {0};
    int AadharAbsent[100] = {0};
    int AadharPresentAgain[100] = {0};

    FILE *f1 = fopen("output.txt", "r");
    FILE *f2 = fopen("output2.txt", "r");
    FILE *f3 = fopen("outputresult.txt", "w");
    FILE *f4 = fopen("Probes.txt", "w");

    int counter = 0;
    while (counter < 1000)
    {
        int key;
        fscanf(f1, "%d", &key);
        mainArray[counter] = key;
        insertIntoTable(hashTable1, key, hashTableSize);
        counter++;
    }

    int selectedAadharPresent;
    int j = 0;
    while (j < 100)
    {
        fscanf(f2, "%d", &selectedAadharPresent);
        AadharPresent[j] = selectedAadharPresent;
        j++;
    }

    int selectedAadharAbsent;
    int k = 0;
    while (k < 100)
    {
        fscanf(f2, "%d", &selectedAadharAbsent);
        AadharAbsent[k] = selectedAadharAbsent;
        k++;
    }

    int selectedAadharAgain;
    int l = 0;
    while (l < 100)
    {
        fscanf(f2, "%d", &selectedAadharAgain);
        AadharPresentAgain[l] = selectedAadharAgain;
        l++;
    }

    int totalProbes = 0;
    for (int i = 0; i < 100; i++)
    {
        int key = AadharPresent[i];
        int probes = probesReportInSearching(hashTable1, key, "Successful searches from the hash table", f3);
        totalProbes += probes;
    }
    fprintf(f3, "\n");

    // Report the total probes in the Probes.txt file
    fprintf(f4, "Total probes for first successful search: %d\nAnd the average probes count is :%f", totalProbes, (float)totalProbes / 100);
    fprintf(f4, "\n");

    // Now, let's find the indexes of keys from AadharPresent[] in hashTable1
    for (int i = 0; i < 100; i++)
    {
        int key = AadharPresent[i];
        for (int j = 0; j < hashTableSize; j++)
        {
            if (hashTable1[j] == key)
            {
                keysIndexToBeDeletedFromHashTable[i] = j;
                break;
            }
        }
    }

    // Deleting the keys from the hash table
    for (int i = 0; i < 100; i++)
    {
        hashTable1[keysIndexToBeDeletedFromHashTable[i]] = 0;
    }

    // Loop through AadharPresent and replace common elements in mainArray with zeros
    for (int i = 0; i < 100; i++)
    {
        int key = AadharPresent[i];
        for (int j = 0; j < 1000; j++)
        {
            if (mainArray[j] == key)
            {
                mainArray[j] = 0;
                break;
            }
        }
    }

    // Loop through mainArray and copy non-zero values to updatedMainArray
    int updatedMainArrayIndex = 0;
    for (int i = 0; i < 1000; i++)
    {
        if (mainArray[i] != 0)
        {
            updatedMainArray[updatedMainArrayIndex] = mainArray[i];
            updatedMainArrayIndex++;
        }
    }

    for (int i = 0; i < hashTableSize; i++)
    {
        hashTable1[i] = 0;
    }

    int Secondcounter = 0;
    while (Secondcounter < sizeAfterdeletion)
    {
        int key = updatedMainArray[Secondcounter];
        insertIntoTable(hashTable1, key, hashTableSize);
        Secondcounter++;
    }

    // Now, let's count probes for searching keys in the hash table
    totalProbes = 0;
    for (int i = 0; i < 100; i++)
    {
        int key = AadharPresentAgain[i];
        int probes = probesReportInSearching(hashTable1, key, "Successful searches from the hash table", f3);
        totalProbes += probes;
    }
    fprintf(f3, "\n");

    // Report the total probes in the Probes.txt file
    fprintf(f4, "Total probes for second successful search: %d\nAnd the average probes count is :%f", totalProbes, (float)totalProbes / 100);
    fprintf(f4, "\n");

    // Now, let's count probes for searching keys in the hash table
    totalProbes = 0;
    for (int i = 0; i < 100; i++)
    {
        int key = AadharAbsent[i];
        int probes = probesReportInSearching(hashTable1, key, "Unsuccessful searches from the hash table", f3);
        totalProbes += probes;
    }
    fprintf(f3, "\n");

    // Report the total probes in the Probes.txt file
    fprintf(f4, "Total probes for third Unsuccessful search: %d\nAnd the average probes count is :%f", totalProbes, (float)totalProbes / 100);
    fprintf(f4, "\n");

    fclose(f1);
    fclose(f2);
    fclose(f3);
    fclose(f4);
    return 0;
}
